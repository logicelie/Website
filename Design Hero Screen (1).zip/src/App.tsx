import AppWithRouting from './AppWithRouting';

export default function App() {
  return <AppWithRouting />;
}
